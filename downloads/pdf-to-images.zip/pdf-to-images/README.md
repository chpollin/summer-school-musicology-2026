# README: PDF pages as images

This exercise renders each page of a PDF as a numbered PNG file. The input PDF is preserved. The output folder must be new.

## Run in a terminal

Open this folder in Visual Studio Code and choose **Terminal → New Terminal**.

```shell
python --version
python -m pip install pypdfium2 Pillow
python pdf_to_images.py example.pdf --output images
```

If your system provides Python as `python3`, use `python3` in all three commands.

The output is `images/page-001.png` and `images/page-002.png`. Check the number and order of the images against the PDF. Inspect the greeting at a useful zoom level.

Run another conversion at 300 DPI in a separate folder:

```shell
python pdf_to_images.py example.pdf --output images-300 --dpi 300
```

Doubling the DPI doubles both pixel dimensions and produces roughly four times as many pixels. It does not recover detail missing from the original scan. Rendering a page produces an image; extracting its text requires a separate transcription or OCR step.

An environment managed by uv can run the script's inline dependencies directly:

```shell
uv run pdf_to_images.py example.pdf --output images
```

## Source and preparation

Literaturarchiv Salzburg. Lotte Altmann to Anna Meingast, 6 July 1936. SZ-SAM/B10.1. Stefan Zweig Digital. Rights statement in METS: CC BY.

- Original object: https://gams.uni-graz.at/o:szd.1131
- METS record: https://gams.uni-graz.at/o:szd.1131/METS_SOURCE
- IIIF manifest: https://gams.uni-graz.at/o:szd.1131/sdef:IIIF/getManifest

The example PDF was assembled for this exercise from the original object's front and reverse, delivered as 1000-pixel-wide IIIF JPEG renditions. Their order follows METS. These are source images, not AI-generated illustrations. The PDF is an exercise derivative rather than an archival master.

The script was checked with Python, pypdfium2 5.13.0 and Pillow 12.3.0. It produced two PNG pages at 150 DPI and rejected reuse of the same output directory.

## Documentation

pypdfium2. Python API documentation, sections Document and Page.
https://pypdfium2.readthedocs.io/en/stable/python_api.html
