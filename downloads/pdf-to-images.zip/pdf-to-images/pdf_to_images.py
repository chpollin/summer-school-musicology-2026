# /// script
# requires-python = ">=3.11"
# dependencies = ["pypdfium2>=4.30,<6", "Pillow>=11,<13"]
# ///
"""Render a PDF into numbered PNG pages for the KUG research-data workshop.

Run: uv run pdf_to_images.py example.pdf --output images --dpi 150
The same file runs with Python when its declared dependencies are installed.
Output uses a new directory so a previous result cannot be overwritten.
"""

import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pdf", type=Path, help="Input PDF file")
    parser.add_argument("--output", type=Path, default=Path("images"))
    parser.add_argument("--dpi", type=int, default=150)
    args = parser.parse_args()
    if not args.pdf.is_file():
        parser.error(f"Input PDF does not exist: {args.pdf}")
    if args.dpi <= 0:
        parser.error("--dpi must be a positive integer.")
    if args.output.exists():
        parser.error(f"Output already exists. Choose a new folder: {args.output}")

    import pypdfium2 as pdfium

    with pdfium.PdfDocument(args.pdf) as document:
        args.output.mkdir(parents=True)
        for index in range(len(document)):
            page = document[index]
            try:
                bitmap = page.render(scale=args.dpi / 72)
                try:
                    image = bitmap.to_pil()
                    output = args.output / f"page-{index + 1:03}.png"
                    image.save(output, dpi=(args.dpi, args.dpi))
                    print(f"[OK] {output} ({image.width} x {image.height} pixels)")
                finally:
                    bitmap.close()
            finally:
                page.close()
        print(f"[OK] Rendered {len(document)} pages at {args.dpi} DPI.")


if __name__ == "__main__":
    main()
